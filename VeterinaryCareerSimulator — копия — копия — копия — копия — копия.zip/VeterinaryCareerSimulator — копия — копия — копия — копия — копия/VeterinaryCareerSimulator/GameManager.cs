﻿using System;
using System.Collections.Generic;

namespace VeterinaryCareerSimulator
{
    public class GameManager
    {
        public Player Player { get; set; }
        private readonly Random random = new Random();

        public GameManager(string playerName)
        {
            Player = new Player(playerName);
        }

        public Animal GenerateAnimal()
        {
            string[] species = { "Собака", "Кошка", "Птица", "Грызун", "Экзотическая птица", "Редкая рептилия" };
            string[] injuries = { "Рана", "Перелом", "Отравление", "Инфекция", "Редкое заболевание", "Паразиты" };

            string name = "Животное #" + random.Next(1, 100);
            string randomSpecies = species[random.Next(species.Length)];
            string randomInjury = injuries[random.Next(injuries.Length)];
            int rarity = random.Next(1, 6); // От 1 до 5
            bool requiresHighLevel = random.Next(10) == 0; // 10% шанс, что потребуется лечение на высоком уровне

            return new Animal(name, randomSpecies, randomInjury, rarity, requiresHighLevel);
        }

        public TreatmentResult TreatAnimal(Animal animal)
        {
            if (Player.JobTitle == "Младший ветеринарный врач" && animal.Rarity >= 3)
            {
                return new TreatmentResult(0, "У вас слишком мало знаний в этой области для лечения такого животного.");
            }
            else if (animal.RequiresHighLevelTreatment && Player.JobTitle != "Владелец ветеринарной клиники")
            {
                return new TreatmentResult(0, "Это животное требует лечения на более высоком уровне! Вам нужно стать владельцем клиники.");
            }
            else
            {
                int experience = animal.Rarity * random.Next(5, 15);
                string message = $"Вы вылечили {animal.Species} {animal.Name} с травмой {animal.Injury}. Получено {experience} опыта.";
                Player.Experience += experience;
                return new TreatmentResult(experience, message);
            }
        }
    }
}
