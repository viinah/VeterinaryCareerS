﻿using System;
using System.Windows;

namespace VeterinaryCareerSimulator
{
    public partial class ShopWindow : Window
    {
        private GameManager _gameManager;

        public ShopWindow(GameManager gameManager)
        {
            InitializeComponent();
            _gameManager = gameManager;
        }

        private void BuyOxygenConcentrator_Click(object sender, RoutedEventArgs e)
        {
            BuyEquipment("Концентратор кислорода Longfian Jay-10", 70, 30);
        }

        private void BuyAnesthesiaMachine_Click(object sender, RoutedEventArgs e)
        {
            BuyEquipment("Наркозно-дыхательный аппарат BMV BAM-8", 100, 60);
        }

        private void BuyUltrasoundMachine_Click(object sender, RoutedEventArgs e)
        {
            BuyEquipment("Аппарат УЗИ SIUI Apogee 5800 Genius", 120, 90);
        }

        private void BuyXRayMachine_Click(object sender, RoutedEventArgs e)
        {
            BuyEquipment("Рентгеновский аппарат VetRaySys-iPet-X", 150, 130);
        }

        private void BuyEquipment(string equipmentName, double cost, int experience)
        {
            if (_gameManager.Player.Money >= cost)
            {
                _gameManager.Player.Money -= cost;
                _gameManager.Player.Experience += experience;

                //  Как обновить UI главного окна из ShopWindow?
                //  Нужно передать ссылку на главное окно или использовать события.
                //  Самый простой способ - просто закрыть ShopWindow, и MainWindow обновится при следующем тике таймера.

                MessageBox.Show($"Куплено: {equipmentName}. Получено {experience} опыта.", "Покупка"); //  Убрать AppendToGameLog.

                Close(); //  Закрываем окно. MainWindow обновится при следующем тике таймера.
            }
            else
            {
                MessageBox.Show("Недостаточно денег!");
            }
        }
    }
}
