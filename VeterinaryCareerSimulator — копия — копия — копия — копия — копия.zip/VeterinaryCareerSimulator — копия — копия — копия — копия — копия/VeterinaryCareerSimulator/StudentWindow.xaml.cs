﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.ComponentModel;
using System.Security.Policy;

namespace VeterinaryCareerSimulator
{
    public partial class StudentWindow : Window, INotifyPropertyChanged
    {
        private Student _student;
        public Student Student
        {
            get { return _student; }
            set
            {
                _student = value;
                OnPropertyChanged(nameof(Student));
            }
        }
        private DateTime _nextLectureTime;
        private DateTime _nextPracticeTime;
        private DateTime _nextScholarshipTime;
        private DateTime _nextParentsTime;
        private readonly Random _random = new Random();
        private DispatcherTimer _timer;
        private string _eventLog;
        private bool _examPassed = false; // Флаг, указывающий, сдал ли студент экзамен
        private DateTime _lastStudyTime = DateTime.MinValue;
        private DateTime _lastPracticeTime = DateTime.MinValue;
        private DateTime _lastWorkTime = DateTime.MinValue;
        private const int ActionInterval = 5; // Интервал в секундах
        private const int WorkInterval = 10; // Интервал подработки в секундах

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public string EventLog
        {
            get { return _eventLog; }
            set
            {
                _eventLog = value;
                OnPropertyChanged(nameof(EventLog));
            }
        }

        public StudentWindow()
        {
            InitializeComponent();

            Student = new Student();
            DataContext = Student;

            _nextLectureTime = DateTime.Now.AddSeconds(15);
            _nextPracticeTime = DateTime.Now.AddSeconds(30);
            _nextScholarshipTime = DateTime.Now.AddMinutes(2);
            _nextParentsTime = DateTime.Now.AddSeconds(_random.Next(30, 100)); // Случайный интервал от 1 до 5 минут

            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(3);
            _timer.Tick += Timer_Tick;
            _timer.Start();

            EventLog = "Игра началась!\n";
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateTimers();
            CheckExamAvailability();
            // Автоматическое снижение ресурсов
            Student.Hunger -= 1;
            Student.Mood -= 1;
            Student.Health -= 1;

            //Уменьшение значений, чтобы они не уходили в минус.
            if (Student.Hunger < 0) Student.Hunger = 0;
            if (Student.Mood < 0) Student.Mood = 0;
            if (Student.Health < 0) Student.Health = 0;

            // Проверяем, достигли ли ресурсы 0
            if (Student.Health <= 0 || Student.Hunger <= 0 || Student.Mood <= 0)
            {
                _timer.Stop();
                MessageBox.Show("Вы не смогли выжить в студенческой жизни!", "Конец игры");
                Application.Current.Shutdown();
            }
        }

        private void UpdateTimers()
        {
            // Лекции
            if (DateTime.Now >= _nextLectureTime)
            {
                _nextLectureTime = DateTime.Now.AddSeconds(15);
            }

            // Практика
            if (DateTime.Now >= _nextPracticeTime)
            {
                _nextPracticeTime = DateTime.Now.AddSeconds(30);
            }

            // Стипендия
            if (DateTime.Now >= _nextScholarshipTime)
            {
                Student.Money += 300;
                _nextScholarshipTime = DateTime.Now.AddMinutes(2);
                AddToEventLog("Получена стипендия! +300");
            }

            // Помощь от родителей
            if (DateTime.Now >= _nextParentsTime)
            {
                int amount = _random.Next(100, 151);
                Student.Money += amount;
                _nextParentsTime = DateTime.Now.AddSeconds(_random.Next(60, 301));
                AddToEventLog($"Получена помощь от родителей! +{amount}");
            }

            //Обновление таймеров на UI
            ScholarshipTimerTextBlock.Text = FormatTimeSpan(_nextScholarshipTime - DateTime.Now);
            ParentsTimerTextBlock.Text = FormatTimeSpan(_nextParentsTime - DateTime.Now);
        }

        private string FormatTimeSpan(TimeSpan timeSpan)
        {
            return $"{timeSpan.Minutes:D2}:{timeSpan.Seconds:D2}";
        }

        private void StudyButton_Click(object sender, EventArgs e)
        {
            if (DateTime.Now - _lastStudyTime >= TimeSpan.FromSeconds(ActionInterval))
            {
                Student.TheoreticalKnowledge += 10;
                AddToEventLog("Посетил лекцию! +10 к теоретическим знаниям");
                _lastStudyTime = DateTime.Now; // Обновляем время последнего посещения

                // Снижаем голод и настроение
                Student.Hunger -= 5;
                Student.Mood -= 5;

                // Проверяем, чтобы значения не уходили в минус
                Student.Hunger = Math.Max(0, Student.Hunger);
                Student.Mood = Math.Max(0, Student.Mood);
            }
            else
            {
                MessageBox.Show("Вы уже были на учебе! Подождите.");
            }
        }

        private void PracticeButton_Click(object sender, EventArgs e)
        {
            if (DateTime.Now - _lastPracticeTime >= TimeSpan.FromSeconds(ActionInterval))
            {
                Student.PracticalSkills += 20;
                AddToEventLog("Посетил практику! +20 к практическим навыкам");
                _lastPracticeTime = DateTime.Now; // Обновляем время последнего посещения

                // Снижаем голод и настроение
                Student.Hunger -= 5;
                Student.Mood -= 5;

                // Проверяем, чтобы значения не уходили в минус
                Student.Hunger = Math.Max(0, Student.Hunger);
                Student.Mood = Math.Max(0, Student.Mood);
            }
            else
            {
                MessageBox.Show("Вы уже были на практике! Подождите.");
            }
        }
        private void EatButton_Click(object sender, RoutedEventArgs e)
        {
            double cost = 50; // Стоимость еды
            if (Student.Money >= cost)
            {
                Student.Hunger += 30;
                Student.Money -= cost;
                if (Student.Hunger > 100) Student.Hunger = 100; //Максимальное значение
                AddToEventLog("Поел! +30 к голоду, -" + cost + " к деньгам");
            }
            else
            {
                MessageBox.Show("Недостаточно денег, чтобы поесть!");
            }
        }
        private void RestButton_Click(object sender, RoutedEventArgs e)
        {
            double cost = 30; // Стоимость отдыха
            if (Student.Money >= cost)
            {
                Student.Mood += 20;
                Student.Health += 10;
                Student.Money -= cost;
                if (Student.Mood > 100) Student.Mood = 100; //Максимальное значение
                if (Student.Health > 100) Student.Health = 100; //Максимальное значение
                AddToEventLog("Отдохнул! +20 к настроению, +10 к здоровью, -" + cost + " к деньгам");
            }
            else
            {
                MessageBox.Show("Недостаточно денег, чтобы отдохнуть!");
            }
        }

        private void WorkButton_Click(object sender, RoutedEventArgs e)
        {
            if (DateTime.Now - _lastWorkTime >= TimeSpan.FromSeconds(WorkInterval))
            {
                Student.Money += 100;

                // Проверяем, не уйдут ли навыки в минус
                int newTheoreticalKnowledge = Student.TheoreticalKnowledge - 10;
                int newPracticalSkills = Student.PracticalSkills - 10;

                Student.TheoreticalKnowledge = Math.Max(0, newTheoreticalKnowledge);
                Student.PracticalSkills = Math.Max(0, newPracticalSkills);

                Student.Health -= 10;
                Student.Mood -= 10;

                AddToEventLog("Подрабатывал официантом! +100 к деньгам, -30 к теоретическим знаниям, -30 к практическим навыкам");
                _lastWorkTime = DateTime.Now; // Обновляем время последней подработки
            }
            else
            {
                MessageBox.Show("Вы слишком устали, чтобы подрабатывать! Подождите.");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Student.SaveGame("student_savegame.json");
            AddToEventLog("Игра сохранена.");
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            Student loadedStudent = Student.LoadGame("student_savegame.json");
            if (loadedStudent != null)
            {
                Student = loadedStudent;
                DataContext = Student; // Обновляем DataContext, чтобы UI тоже обновился
                AddToEventLog("Игра загружена.");
            }
            else
            {
                AddToEventLog("Файл сохранения не найден.");
            }
        }

        private void AddToEventLog(string message)
        {
            EventLog = message + "\n" + EventLog;
        }
        private void CheckExamAvailability()
        {
            ExamButton.IsEnabled = Student.TheoreticalKnowledge >= 300 && Student.PracticalSkills >= 400;
        }

        private void ExamButton_Click(object sender, RoutedEventArgs e)
        {

            StartClinicButton.IsEnabled = true;
            MessageBox.Show("Поздравляю! Вы сдали итоговый экзамен!", "Экзамен сдан!");

            _examPassed = true;

        }

        private void StartClinicButton_Click(object sender, RoutedEventArgs e)
        {
            if (_examPassed)
            {
                string playerName = Microsoft.VisualBasic.Interaction.InputBox("Введите имя вашего ветеринара:", "Новая игра");
                if (string.IsNullOrWhiteSpace(playerName))
                {
                    playerName = "Безымянный ветеринар";
                }

                MainWindow mainWindow = new MainWindow(playerName);
                mainWindow.Show();
                _timer.Stop(); // Останавливаем таймер
                this.Close();
            }
            else
            {
                MessageBox.Show("Вы должны сдать итоговый экзамен, чтобы начать работу в ветеринарной клинике!", "Ошибка");
            }
        }

        

    }
}
