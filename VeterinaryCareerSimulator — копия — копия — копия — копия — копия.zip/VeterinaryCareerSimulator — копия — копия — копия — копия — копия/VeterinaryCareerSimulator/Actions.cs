﻿namespace VeterinaryCareerSimulator
{
    public enum Actions
    {
        Study,
        Practice,
        Eat,
        Rest,
        Work,
        ReceiveScholarship,
        ReceiveHelpFromParents
    }
}

