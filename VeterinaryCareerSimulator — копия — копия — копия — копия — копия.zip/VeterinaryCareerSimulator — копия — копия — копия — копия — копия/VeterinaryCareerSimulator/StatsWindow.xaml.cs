﻿using System.Windows;

namespace VeterinaryCareerSimulator
{
    public partial class StatsWindow : Window
    {
        private Player player;
        private MainWindow mainWindow; // Ссылка на главное окно

        public StatsWindow(Player player, MainWindow mainWindow)
        {
            InitializeComponent();
            this.player = player;
            this.mainWindow = mainWindow; // Сохраняем ссылку
            UpdateStats();
        }

        public void UpdateStats()
        {
            HealthProgressBar.Value = player.Health;
            HungerProgressBar.Value = player.Hunger;
            MoodProgressBar.Value = player.Mood;
        }

        private void ReplenishHealthButton_Click(object sender, RoutedEventArgs e)
        {
            ReplenishResource(player.Health, "Health");
        }

        private void ReplenishHungerButton_Click(object sender, RoutedEventArgs e)
        {
            ReplenishResource(player.Hunger, "Hunger");
        }

        private void ReplenishMoodButton_Click(object sender, RoutedEventArgs e)
        {
            ReplenishResource(player.Mood, "Mood");
        }

        private void ReplenishResource(int currentValue, string resourceName)
        {
            double cost = 30;
            double replenishAmount = 20; // 20 процентов
            if (player.Money >= cost)
            {
                player.Money -= cost;
                double newValue = currentValue + replenishAmount;
                if (newValue > 100)
                {
                    newValue = 100;
                }
                switch (resourceName)
                {
                    case "Health":
                        player.Health = (int)newValue;
                        break;
                    case "Hunger":
                        player.Hunger = (int)newValue;
                        break;
                    case "Mood":
                        player.Mood = (int)newValue;
                        break;
                }
                UpdateStats();
                mainWindow.UpdateUI(); // Обновляем UI главного окна
            }
            else
            {
                MessageBox.Show("Недостаточно денег!");
            }
        }
    }
}
