﻿using System;
using System.ComponentModel;
using System.IO;
using System.Text.Json;

namespace VeterinaryCareerSimulator
{
    public class Student : INotifyPropertyChanged
    {
        private int _theoreticalKnowledge;
        public int TheoreticalKnowledge
        {
            get { return _theoreticalKnowledge; }
            set
            {
                _theoreticalKnowledge = value;
                OnPropertyChanged(nameof(TheoreticalKnowledge));
            }
        }

        private int _practicalSkills;
        public int PracticalSkills
        {
            get { return _practicalSkills; }
            set
            {
                _practicalSkills = value;
                OnPropertyChanged(nameof(PracticalSkills));
            }
        }

        private int _health;
        public int Health
        {
            get { return _health; }
            set
            {
                _health = value;
                OnPropertyChanged(nameof(Health));
            }
        }

        private int _hunger;
        public int Hunger
        {
            get { return _hunger; }
            set
            {
                _hunger = value;
                OnPropertyChanged(nameof(Hunger));
            }
        }

        private int _mood;
        public int Mood
        {
            get { return _mood; }
            set
            {
                _mood = value;
                OnPropertyChanged(nameof(Mood));
            }
        }

        private double _money;
        public double Money
        {
            get { return _money; }
            set
            {
                _money = value;
                OnPropertyChanged(nameof(Money));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Student()
        {
            TheoreticalKnowledge = 20;
            PracticalSkills = 10;
            Health = 100;
            Hunger = 100;
            Mood = 70;
            Money = 0;
        }

        public void SaveGame(string filename)
        {
            string jsonString = JsonSerializer.Serialize(this);
            File.WriteAllText(filename, jsonString);
        }

        public static Student LoadGame(string filename)
        {
            if (File.Exists(filename))
            {
                string jsonString = File.ReadAllText(filename);
                Student student = JsonSerializer.Deserialize<Student>(jsonString);
                return student;
            }
            else
            {
                return null;
            }
        }
    }
}

