﻿using System;
using System.IO;
using System.Text.Json;

namespace VeterinaryCareerSimulator
{
    public class Player
    {
        public string Name { get; set; }
        public string JobTitle { get; set; } // Должность
        public int Experience { get; set; }
        public double Money { get; set; }
        public int Health { get; set; }
        public int Hunger { get; set; }
        public int Mood { get; set; }
        public DateTime LastSalaryDate { get; set; }

        // Конструктор
        public Player(string name)
        {
            Name = name;
            JobTitle = "Младший ветеринарный врач"; // Начальная должность
            Experience = 0;
            Money = 300; // Начальный капитал
            Health = 100;
            Hunger = 100;
            Mood = 100;
            LastSalaryDate = DateTime.Now.AddDays(-15); // Чтобы сразу получить первую зарплату
        }

        // Метод для получения зарплаты
        public void GetSalary()
        {
            if (DateTime.Now.Subtract(LastSalaryDate).TotalSeconds >= 150)
            {
                double salary = GetSalaryAmount();
                Money += salary;
                LastSalaryDate = DateTime.Now;
                Hunger = 100; // Восполняем ресурсы
                Health = 100;
                Mood = 100;
            }
        }

        // Метод для определения размера зарплаты в зависимости от должности
        public double GetSalaryAmount()
        {
            switch (JobTitle)
            {
                case "Младший ветеринарный врач":
                    return 400;
                case "Ветеринарный врач":
                    return 700;
                case "Владелец ветеринарной клиники":
                    return 1500;
                default:
                    return 0;
            }
        }

        // Метод для повышения должности
        public bool Promote()
        {
            string oldJobTitle = JobTitle; // Запоминаем старую должность

            switch (JobTitle)
            {
                case "Младший ветеринарный врач":
                    if (Experience >= 500)
                    {
                        JobTitle = "Ветеринарный врач";
                        Experience = 0;
                    }
                    break;
                case "Ветеринарный врач":
                    if (Experience >= 1500)
                    {
                        JobTitle = "Владелец ветеринарной клиники";
                        Experience = 0;
                    }
                    break;
                case "Владелец ветеринарной клиники":
                    break;
            }

            return oldJobTitle != JobTitle; // Возвращаем true, если должность изменилась
        }

        public void SaveGame(string filename)
        {
            string jsonString = JsonSerializer.Serialize(this);
            File.WriteAllText(filename, jsonString);
        }

        public static Player LoadGame(string filename)
        {
            if (File.Exists(filename))
            {
                string jsonString = File.ReadAllText(filename);
                Player player = JsonSerializer.Deserialize<Player>(jsonString);
                return player;
            }
            else
            {
                return null;
            }
        }

        public void UpdateNeeds()
        {
            Hunger -= 1;
            Mood -= 1;
            Health -= 1;

            if (Hunger <= 0 || Mood <= 0 || Health <= 0)
            {
                Environment.Exit(0); // Завершить игру
            }
        }
    }
}
