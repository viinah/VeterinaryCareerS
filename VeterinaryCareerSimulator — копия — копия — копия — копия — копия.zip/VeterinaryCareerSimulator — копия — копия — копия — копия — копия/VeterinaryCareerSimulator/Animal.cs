﻿using System;

namespace VeterinaryCareerSimulator
{
    public class Animal
    {
        public string Name { get; set; }
        public string Species { get; set; }
        public string Injury { get; set; }
        public int Rarity { get; set; } // От 1 (обычный) до 5 (очень редкий)
        public bool RequiresHighLevelTreatment { get; set; } // Требуется ли высокая должность для лечения

        public Animal(string name, string species, string injury, int rarity, bool requiresHighLevel)
        {
            Name = name;
            Species = species;
            Injury = injury;
            Rarity = rarity;
            RequiresHighLevelTreatment = requiresHighLevel;
        }
    }
}
