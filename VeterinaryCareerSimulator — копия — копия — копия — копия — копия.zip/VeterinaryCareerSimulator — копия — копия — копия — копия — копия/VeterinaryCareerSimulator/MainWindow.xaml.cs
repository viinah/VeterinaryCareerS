﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.Linq;

namespace VeterinaryCareerSimulator
{
    public partial class MainWindow : Window
    {
        private GameManager gameManager;
        private DispatcherTimer timer;
        private DateTime _nextBonusTime;
        private const int BonusInterval = 80; // Интервал премии в секундах
        private DateTime _nextTipTime;
        private readonly Random _random = new Random();
        private const int MinTipInterval = 10; // Минимальный интервал для чаевых в секундах
        private const int MaxTipInterval = 100; // Максимальный интервал для чаевых в секундах
        private const int MinTipAmount = 60; // Минимальная сумма чаевых
        private const int MaxTipAmount = 100; // Максимальная сумма чаевых


        public MainWindow(string playerName)
        {
            InitializeComponent();

            gameManager = new GameManager(playerName);
            UpdateUI();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1); // Обновляем таймер каждую секунду
            timer.Tick += Timer_Tick;
            timer.Start();

            UpdateSalaryTimer(); // Initial update of the salary timer
            _nextBonusTime = DateTime.Now.AddSeconds(BonusInterval);
            _nextTipTime = DateTime.Now.AddSeconds(_random.Next(MinTipInterval, MaxTipInterval + 1));
            UpdateTimeLeftForBonus();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            gameManager.Player.UpdateNeeds();
            UpdateUI();
            UpdateSalaryTimer(); // Обновляем таймер каждую секунду
            CheckForBonus(); // Обновляем таймер премии
            CheckForTip(); // Проверяем, не пришло ли время для чаевых

            // Проверяем, достигли ли ресурсы 20%
            if (gameManager.Player.Health <= 20 || gameManager.Player.Hunger <= 20 || gameManager.Player.Mood <= 20)
            {
                // Проверяем, не показывалось ли уже сообщение о низких ресурсах
                if (!lowResourceWarningShown)
                {
                    MessageBox.Show("Пониженный процент параметров голода, здоровья или настроения!", "Внимание!");
                    lowResourceWarningShown = true;
                }
            }
            else
            {
                // Если все ресурсы выше 20%, сбрасываем флаг
                lowResourceWarningShown = false;
            }

            if (gameManager.Player.Health <= 0 || gameManager.Player.Hunger <= 0 || gameManager.Player.Mood <= 0)
            {
                timer.Stop();
                MessageBox.Show("Игра закончена. Вы недостаточно заботились о своем здоровье.", "Конец игры");
                Application.Current.Shutdown();
            }
        }

        public void UpdateUI()  // Сделан public
        {
            PlayerNameTextBlock.Text = gameManager.Player.Name;
            JobTitleTextBlock.Text = gameManager.Player.JobTitle;
            MoneyTextBlock.Text = gameManager.Player.Money.ToString("C");
            ExperienceTextBlock.Text = gameManager.Player.Experience.ToString();
        }

        private void TreatAnimalButton_Click(object sender, RoutedEventArgs e)
        {
            Animal animal = gameManager.GenerateAnimal();
            TreatmentWindow treatmentWindow = new TreatmentWindow(animal, gameManager.Player);

            if (treatmentWindow.ShowDialog() == true)
            {
                TreatmentResult result = treatmentWindow.TreatmentResult;
                if (result.Experience > 0)
                {
                    gameManager.Player.Experience += result.Experience;
                }
                UpdateDynamicInfo(result.Message);
                UpdateUI();
            }
            else
            {
                UpdateDynamicInfo("Лечение отменено.");
            }
        }

        private DateTime nextSalaryTime = DateTime.Now.AddSeconds(150); // Время следующей зарплаты

        private void GetSalaryButton_Click(object sender, RoutedEventArgs e)
        {
            if (DateTime.Now >= nextSalaryTime)
            {
                gameManager.Player.GetSalary();
                UpdateUI();
                UpdateDynamicInfo($"Получена зарплата: {gameManager.Player.GetSalaryAmount():C}");
                nextSalaryTime = DateTime.Now.AddSeconds(150); // Устанавливаем время следующей зарплаты
                UpdateSalaryTimer(); // Обновляем таймер сразу после получения зарплаты
            }
            else
            {
                UpdateDynamicInfo("Зарплата еще не пришла.");
            }
        }


        private void PromoteButton_Click(object sender, RoutedEventArgs e)
        {
            if (gameManager.Player.Promote())
            {
                MessageBox.Show("Поздравляю! Вы перешли на новую должность!", "Повышение!");
            }
            else
            {
                UpdateDynamicInfo("Недостаточно опыта для повышения."); // Сообщение, если не хватает опыта
            }
            UpdateUI();
            UpdateDynamicInfo("Попытка повышения."); //Общее сообщение, не зависящее от результата.
        }

        private void StatsButton_Click(object sender, RoutedEventArgs e)
        {
            StatsWindow statsWindow = new StatsWindow(gameManager.Player, this); // Передаем ссылку на главное окно
            statsWindow.Show();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            gameManager.Player.SaveGame("savegame.json");
            AppendToGameLog("Игра сохранена.");
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            Player loadedPlayer = Player.LoadGame("savegame.json");
            if (loadedPlayer != null)
            {
                gameManager.Player = loadedPlayer;
                UpdateUI();
                AppendToGameLog("Игра загружена.");
            }
            else
            {
                AppendToGameLog("Файл сохранения не найден.");
            }
        }

        private void AppendToGameLog(string message)
        {
            GameLogTextBlock.Text = message + "\n" + GameLogTextBlock.Text;
        }

        private void UpdateDynamicInfo(string message)
        {
            DynamicInfoTextBlock.Text = message;
        }

        private bool lowResourceWarningShown = false; // Флаг для отслеживания, было ли показано предупреждение о низких ресурсах

        private void UpdateSalaryTimer()
        {
            TimeSpan timeLeft = nextSalaryTime - DateTime.Now;
            if (timeLeft.TotalSeconds > 0)
            {
                SalaryTimerTextBlock.Text = $"До следующей зарплаты: {timeLeft.Minutes:D2}м {timeLeft.Seconds:D2}с";
            }
            else
            {
                SalaryTimerTextBlock.Text = "Зарплата готова к получению!";
            }
        }

        private void OpenShopButton_Click(object sender, RoutedEventArgs e)
        {
            ShopWindow shopWindow = new ShopWindow(gameManager); // Передаем gameManager
            shopWindow.ShowDialog();
        }

        private void CheckForBonus()
        {
            UpdateTimeLeftForBonus();
        }

        private void GetBonusButton_Click(object sender, RoutedEventArgs e)
        {
            if (DateTime.Now >= _nextBonusTime)
            {
                double bonusAmount = 0;

                // Определяем сумму премии в зависимости от должности
                if (gameManager.Player.JobTitle == "Младший ветеринарный врач" || gameManager.Player.JobTitle == "Ветеринарный врач")
                {
                    bonusAmount = 150;
                }
                else if (gameManager.Player.JobTitle == "Владелец ветеринарной клиники")
                {
                    bonusAmount = 250;
                }

                gameManager.Player.Money += bonusAmount;
                UpdateUI();
                UpdateDynamicInfo($"Получена премия: {bonusAmount:C}");
                _nextBonusTime = DateTime.Now.AddSeconds(BonusInterval);
                UpdateTimeLeftForBonus();
            }
            else
            {
                UpdateDynamicInfo("Премия еще не доступна.");
            }

        }


        private void UpdateTimeLeftForBonus()
        {
            TimeSpan timeLeft = _nextBonusTime - DateTime.Now;
            if (timeLeft.TotalSeconds > 0)
            {
                BonusTimerTextBlock.Text = $"До следующей премии: {timeLeft.Minutes:D2}м {timeLeft.Seconds:D2}с";
            }
            else
            {
                BonusTimerTextBlock.Text = "Премия готова к получению!";
            }
        }

        private void CheckForTip()
        {
            if (DateTime.Now >= _nextTipTime)
            {
                int tipAmount = _random.Next(MinTipAmount, MaxTipAmount + 1);
                gameManager.Player.Money += tipAmount;
                UpdateUI();
                string message = $"Получены чаевые от благодарного клиента: {tipAmount:C}";
                UpdateDynamicInfo(message);
                MessageBox.Show(message, "Чаевые от клиента!"); // Показывать всплывающее окно
                _nextTipTime = DateTime.Now.AddSeconds(_random.Next(MinTipInterval, MaxTipInterval + 1));
            }
        }

    }
}
