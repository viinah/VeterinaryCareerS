﻿using System;
using System.Windows;

namespace VeterinaryCareerSimulator
{
    public partial class TreatmentWindow : Window
    {
        private Animal animal;
        private Player player;
        public TreatmentResult TreatmentResult { get; set; }

        public TreatmentWindow(Animal animal, Player player)
        {
            InitializeComponent();
            this.animal = animal;
            this.player = player;

            AnimalInfoTextBlock.Text = $"Вид: {animal.Species}\nИмя: {animal.Name}\nТравма: {animal.Injury}\nРедкость: {animal.Rarity}";

            // Проверяем, может ли игрок лечить это животное
            if (player.JobTitle == "Младший ветеринарный врач" && animal.Rarity >= 3)
            {
                TreatmentNotesTextBox.IsEnabled = false;
                TreatButton.IsEnabled = false;
                AnimalInfoTextBlock.Text += "\nУ вас недостаточно знаний для лечения этого животного.";
            }
        }

        private void TreatButton_Click(object sender, RoutedEventArgs e)
        {
            int experience = 0; // Инициализируем experience
            string message = "";

            if (this.player.JobTitle == "Младший ветеринарный врач" && this.animal.Rarity >= 3)
            {
                message = "У вас недостаточно знаний для лечения этого животного.";
            }
            else
            {
                Random random = new Random();
                experience = animal.Rarity * random.Next(5, 15);
                string notes = TreatmentNotesTextBox.Text;
                message = $"Вы вылечили {animal.Species} {animal.Name} с травмой {animal.Injury}.\nЗаметки: {notes}\nПолучено {experience} опыта.";
            }


            TreatmentResult = new TreatmentResult(experience, message);
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}


