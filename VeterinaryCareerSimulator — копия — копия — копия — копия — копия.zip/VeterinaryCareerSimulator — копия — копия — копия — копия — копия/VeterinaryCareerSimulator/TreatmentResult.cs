﻿namespace VeterinaryCareerSimulator
{
    public class TreatmentResult
    {
        public int Experience { get; set; }
        public string Message { get; set; }

        public TreatmentResult(int experience, string message)
        {
            Experience = experience;
            Message = message;
        }
    }
}
